---
name: viz-charts
description: Render charts, diagrams, and 3D knowledge graphs inside HTML reports. Four capability layers — (1) Mermaid (11 types: flowchart/sequence/class/state/ER/gantt/journey/mindmap/timeline/sankey/gitgraph) for relations and process diagrams; (2) ECharts (25+ types) for data visualization (line/bar/pie/radar/heatmap/sankey/funnel/sunburst/treemap/etc); (3) Self-rolled lightweight SVG components (KPI big-number, sparkline, mini-gauge, progress-bar, tag-cloud); (4) 3D Knowledge Graphs via 3d-force-graph + THREE.js with two builders — code-kg.mjs (extracts file/import graph from JS/TS/Go/Python/Rust repos) and doc-kg.mjs (extracts concept/section graph from markdown). Two render modes — inline live (CDN with jsdelivr→unpkg fallback) and offline SVG (Node.js scripts; mermaid via mermaid-isomorphic→mmdc→placeholder fallback, ECharts via SSR). Two themes (terminal for biz-html-viz, deck for viz-deck). Trigger when a report needs visual data expression, code/doc structure exploration, or chart embedding — explicit "做个架构图 / 加个柱状图 / 数据可视化 / 3D 知识图谱 / chart / mermaid / echarts / KG / knowledge graph" or implicit needs from sister skills (biz-html-viz, viz-deck). ALWAYS START by reading references/decision-tree.md to pick the right visual for the data shape.
license: MIT
---

# viz-charts: 报告内嵌图表与 3D 知识图谱

为 `biz-html-viz`（终端风）和 `viz-deck`（讲演风）两个报告 skill 提供图表渲染与项目可视化能力。**四类视觉表达 + 双模渲染 + 双主题**。

## 四类视觉表达

| 类型 | 类型数 | 路径 |
|---|---|---|
| **Mermaid** 关系/流程图 | 11 | `templates/mermaid/*.mmd` |
| **ECharts** 数据图表 | 25+ | `templates/echarts/*.json` |
| **轻量自研组件** SVG/CSS | 5 | `components/{kpi,sparkline,gauge,progress,tag-cloud}/` |
| **3D 知识图谱** WebGL | 3 viewer | `templates/kg3d/{code,doc,data}-graph.html` |

## 两种渲染模式

| 模式 | 适用 | 实现 | 限制 |
|---|---|---|---|
| **inline** （默认） | 浏览器查看、嵌入 HTML 报告 | CDN 加载 mermaid + echarts + 3d-force-graph，jsdelivr→unpkg 双 fallback | 需联网；大图首次加载略慢 |
| **offline** | 离线归档、打印、邮件附件 | Node 脚本 SSR：ECharts 内置 SVG 渲染器，Mermaid 三档兜底（mermaid-isomorphic → mmdc → placeholder） | 3D KG **无离线模式**（WebGL 不能 SVG 化） |

## 两套主题

| 主题 | 配色 | 字体 | 适配 |
|---|---|---|---|
| `terminal` | 黑 #0a0a0a + 酸黄 #d4ff00 + 灰阶 | JetBrains Mono | biz-html-viz |
| `deck` | 深空 #030711 + 青 #42e8ff + 金 #ffd987 | Inter | viz-deck |

主题文件：`themes/terminal.js` / `themes/deck.js`，均导出 `echartsTheme / mermaidTheme / componentTheme` 三组配置。

## 工作流程

### Step 1 — 强制读决策树

`references/decision-tree.md` 是数据形态 → 视觉类型的选型映射。**任何图表/KG 请求**先读这个再选模板。

### Step 2 — 选模板与契约

读 `references/chart-cookbook.md` 找出对应模板的数据契约。

### Step 3 — 选渲染模式

**Inline 模式**（默认）：

往用户 HTML 报告里嵌入 Mermaid/ECharts/组件块，并在 `</body>` 前加：

```html
<script>
  window.VIZ_CHARTS_OPTS = {
    mermaidTheme: /* terminal | deck mermaidTheme 对象 */,
    echartsTheme: /* 同上的 echartsTheme 对象 */
  };
</script>
<script src="vendor/loaders/cdn-loader.js"></script>
```

**Offline 模式**（仅 Mermaid + ECharts，不含 3D KG）：

```bash
cd .claude/skills/viz-charts/renderers/node
npm install --silent
# Mermaid 离线渲染需要 chromium（仅首次）
npx playwright install chromium

node render-mermaid.mjs --input arch.mmd --output arch.svg --theme terminal
node render-echarts.mjs --input trend.json --output trend.svg --theme deck
node batch.mjs --input-dir ./charts --output-dir ./svgs --theme terminal
```

### Step 4 — 3D KG（特殊路径，只 inline）

读 `references/kg-builder-guide.md` 后：

```bash
node builders/code-kg.mjs --repo ./my-app --output code-kg.json --group-by dir
node builders/doc-kg.mjs --input ./docs --output doc-kg.json
# 渲染：把 JSON 替换进 viewer 模板的 {{KG_DATA_JSON}}
# 见 kg-builder-guide.md 的 "一键渲染脚本"
```

### Step 5 — 一致性检查

- 同一份报告内**所有图表用同一主题**（不要 terminal+deck 混搭）
- ECharts 系列 ≤ 7 个，Mermaid 节点 ≤ 30，超过转 ECharts graph 或 3D KG
- 每张图都有 `<figcaption>` 或 markdown 说明
- offline 输出的 SVG 含 `viewBox` 保证响应式
- 3D KG 单页不超过 1 个（多 WebGL canvas 同页性能崩）

## 标准嵌入结构

### Mermaid

```html
<figure class="chart-mermaid">
  <pre class="mermaid-source">
flowchart LR
    A[Event] --> B{Risk Gate}
    B -->|approved| C[Execute]
  </pre>
  <div class="mermaid-output"></div>
  <figcaption>图 1 · 主流程</figcaption>
</figure>
```

### ECharts

```html
<figure class="chart-echarts">
  <div data-echarts-option='{"xAxis":...,"series":[...]}'
       style="width:100%;height:320px"></div>
  <figcaption>图 2 · 季度营收</figcaption>
</figure>
```

### 自研组件

```html
<div class="kpi-card" data-kpi='{"label":"BURN","value":"¥1.06M","sparkline":[1,2,3,4]}'></div>
<span class="sparkline" data-spark='{"data":[1,2,3]}'></span>
<div class="mini-gauge" data-gauge='{"value":78,"max":100,"label":"完成度"}'></div>
<div class="progress-bar ok" data-progress='{"label":"M0","value":100}'></div>
<div class="tag-cloud" data-tags='[{"label":"Go","weight":10}]'></div>
```

### 3D KG

通常**独立链接**或**iframe 嵌入**，不掺主报告 main flow：

```html
<a href="./code-kg.html" class="btn-card">
  <h3>项目代码 KG (3D 交互)</h3>
  <p>点击在新窗口打开 · 142 文件 · 387 处依赖</p>
</a>
```

## 反模式

- ❌ 同一报告里混用 terminal + deck 主题
- ❌ 用 3D 图表（炫技）—— 仅在信息密度需要时用 3D 知识图谱
- ❌ Mermaid 节点 > 30 还硬画
- ❌ 直接把 ECharts option 写一大段 inline `<script>` 而不用 `data-echarts-option` 契约
- ❌ Offline 输出的 SVG 缺 viewBox
- ❌ 跳过 decision-tree.md 凭直觉选图
- ❌ 把"关键单值"用 ECharts 渲染（应该用 kpi-card 组件）
- ❌ 单页放多个 3D KG（WebGL 资源冲突）

## 文件结构

```
viz-charts/
├── SKILL.md                          这份
├── README.md                         安装与速查
├── references/
│   ├── decision-tree.md              图表选型决策树（必读）
│   ├── chart-cookbook.md             36+ 视觉的数据契约
│   ├── integration-guide.md          如何集成进 biz-html-viz / viz-deck
│   └── kg-builder-guide.md           3D KG 构建指南
├── themes/
│   ├── terminal.js                   biz-html-viz 配色
│   └── deck.js                       viz-deck 配色
├── components/                       5 自研轻量组件
│   ├── kpi/kpi-card.html
│   ├── sparkline/sparkline.html
│   ├── gauge/mini-gauge.html
│   ├── progress/progress-bar.html
│   └── tag-cloud/tag-cloud.html
├── templates/
│   ├── mermaid/                      11 种 .mmd 模板
│   ├── echarts/                      25 种 .json 模板
│   └── kg3d/                         3 种 3D KG viewer
│       ├── code-graph.html
│       ├── doc-graph.html
│       └── data-graph.html
├── builders/                         3D KG 数据生成器
│   ├── code-kg.mjs                   从 git repo 抽代码图
│   └── doc-kg.mjs                    从 markdown 抽文档图
├── vendor/loaders/
│   └── cdn-loader.js                 inline 模式：双 CDN fallback
├── renderers/node/                   offline 模式
│   ├── package.json
│   ├── render-mermaid.mjs
│   ├── render-echarts.mjs
│   └── batch.mjs
└── examples/
    ├── inline-terminal.html          完整 demo（终端风内联）
    ├── inline-deck.html              完整 demo（讲演风内联）
    ├── kg-doc-demo.html              3D 文档 KG 演示
    └── kg-code-demo.html             3D 代码 KG 演示
```
