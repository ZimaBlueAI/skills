---
name: biz-html-viz
description: Generate terminal-grade HTML reports for business decision flows — board briefs, CEO strategy canvas, tech roadmap, MRD/market analysis, project status, dev/QA reports, and retrospectives. Use when the user asks for a "可视化报告 / HTML 报告 / 决策简报 / 路线图 / MRD / 项目看板 / 复盘 / 验收 / retro / board deck" or when a subagent (board-advisor, ceo-decision, chief-architect, product-manager, dev-test-lead, acceptance-retro) needs to render its output. Do NOT use for marketing landing pages, slide decks (.pptx), or playful UI — this skill produces dense, low-chrome, decision-oriented documents.
license: MIT
---

# biz-html-viz: 决策流 HTML 可视化

为投资人会、CEO 决策、架构会、PM/MRD、项目管理、开发测试、验收复盘 7 个商业流程节点生成统一视觉的 HTML 报告。

## 何时使用

被以下任一情况触发：

1. 用户直接要 HTML 形态的商业报告（"给我做一份 MRD 的 HTML"、"复盘报告做成网页"）
2. 一个 subagent（board-advisor / ceo-decision / chief-architect / product-manager / dev-test-lead / acceptance-retro）调用本 skill 来落地它的产出
3. 用户用 `/all-hands` 命令（或要求"走一遍全流程"）触发 orchestrator，最终需要把 6 份报告打包成 index

**不要用于**：营销页、PPT、playful UI、纯文本备忘录、Word 报告（用 docx skill）。

## 工作流程

### 第一步：读 design-system

**强制**先读 `references/design-system.md`。这份文档定义了所有 7 个模板共享的 CSS 变量、字体、骨架结构和视觉禁令。**未读 design-system 直接写 HTML = 视觉不统一 = 返工**。

### 第二步：选模板

| 用户意图 / agent 来源 | 模板 |
|---|---|
| 股东会 / 董事会 / 投资人简报 / board / shareholder | `board-brief.html` |
| CEO 决策 / 战略 / 取舍 / canvas | `ceo-canvas.html` |
| 架构会 / 技术路线 / tech roadmap / 技术选型 | `tech-roadmap.html` |
| MRD / 市场分析 / 需求文档 / 用户画像 / 竞品 | `mrd-report.html` |
| 项目管理 / 看板 / 进度 / 里程碑 / 燃尽 | `project-board.html` |
| 开发汇报 / 测试报告 / SD / TD / QA / 缺陷 | `dev-report.html` |
| 验收 / 复盘 / retro / 总结 / lessons | `retro-report.html` |

### 第三步：填充内容

1. 复制 `templates/{name}.html` 到 `/home/claude/claude-config/output/`（或用户指定目录）
2. 用真实数据替换 `{{占位符}}`——**不要保留任何 `{{ }}`，不要写"示例数据"**
3. 数据不足时：从对话历史中提取；仍不足，主动列出缺什么、并给出**可信的占位估值**（标注 `[ESTIMATED]`），而不是编造
4. 每份报告**头部 meta 4 项必填**：TYPE、DATE、AUTHOR、VERSION
5. 标题用 serif，所有数字用 mono，章节标题用大写 mono——这是统一感来源

### 第四步：交付

- 单文件 HTML（CSS 内联），无外部依赖（除 Google Fonts）
- 文件名格式：`{date}-{type}-{slug}.html`，如 `2026-05-10-mrd-mingjing-v1.html`
- 用 `present_files` 交付，preamble 一句话说明"这是 {类型} 报告，含 N 个章节，关键决策点 X"

## 内容质量准则（少废话核心规则）

- **一段话不超过 3 句**——决策者扫读，不读散文
- **数字优先**——能用数字说的不用形容词（"显著增长" → "+47% MoM"）
- **每个章节有结论句**——放最上面或加 `<blockquote>`
- **风险/决议必带责任人和截止日期**——`@person · YYYY-MM-DD`
- **拒绝凑字数**——空章节直接删除，不要写"暂无"

## 全流程编排（orchestrator 模式）

当用户要"走一遍全流程"或 6 个 subagent 依次调用本 skill 后，再生成一份 `index.html`：

- 列出 6 份子报告链接
- 抽取每份报告的「关键决策」一行摘要
- 提供"统一打印"按钮（CSS `@media print` 已就绪，可直接 Ctrl+P 输出 PDF）
- index 的视觉风格与子报告完全一致

`templates/index.html` 是这个总览模板。

## 模板清单

```
templates/
├── board-brief.html       股东/投资人会
├── ceo-canvas.html        CEO 战略决策画布
├── tech-roadmap.html      架构师技术路线
├── mrd-report.html        PM 市场需求文档
├── project-board.html     PM 项目管理看板
├── dev-report.html        SD/TD 开发测试汇报
├── retro-report.html      验收 + 复盘
└── index.html             全流程总览
```

## 反模式（出现这些 = 失败）

- 出现紫色渐变、玻璃拟态、emoji 装饰
- 章节标题用大字号 sans 而不是 mono uppercase
- 数据用 sans 而不是 mono
- 写了"以下是一些建议..."这类引导废话
- 做出花哨动画或滚动视差
- 7 份报告视觉风格不一致
- 留下未填充的 `{{占位符}}`
