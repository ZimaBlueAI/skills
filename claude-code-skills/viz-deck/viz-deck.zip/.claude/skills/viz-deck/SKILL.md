---
name: viz-deck
description: Generate keynote-grade HTML presentation reports with deep-space cyan/blue/gold aesthetic, glass panels, orbital hero visuals, and reveal-on-scroll animations. Use for stage reports, architecture deep-dives, and competitive landscapes when the audience is investors, clients, or full-team keynote walkthroughs (NOT for engineering scan-reads or printable signoff docs — use biz-html-viz for those). Three templates — stage-report, architecture-deep, competitive-landscape — share one design language. The competitive-landscape template invokes web_search and web_fetch for live research; do NOT fabricate competitor data. Trigger on "讲演 / 演示报告 / keynote / 阶段报告 / 架构深研 / 竞品对比 / stage report / architecture deep dive / competitive landscape".
license: MIT
---

# viz-deck: 讲演级可视化报告

为客户演示、投资人路演、团队 keynote 走读场景生成深空风 HTML 报告。视觉 DNA 源自 Octarus stage-report 系列：玻璃拟态、流光描边、轨道环主视觉、reveal 滚动入场。

## 与 biz-html-viz 的边界

| 维度 | biz-html-viz | viz-deck |
|---|---|---|
| 受众 | 工程师 / CEO / 董事会 | 客户 / 投资人 / 全员 keynote |
| 场景 | 5 分钟扫读、决策签字、打印归档 | 60-90 分钟走读、视觉记忆 |
| 风格 | 黑底 + 酸黄强调 + 等宽 + 零动效 | 深空蓝紫青 + Inter + 微动效 |
| 信息密度 | 极高 | 中等，叙事节奏优先 |
| 文件大小 | ~10KB / 份 | ~40-80KB / 份（含动效与主视觉） |

**同一项目可两个 skill 各出一份**：决策版用 biz-html-viz 打印归档，讲演版用 viz-deck 上台展示。

## 何时使用 viz-deck

被以下任一情况触发：

1. 用户明确说"讲演 / 演示 / keynote / 阶段报告 / 路演 / 给客户看"
2. 用户上传 Octarus stage-report 类样例，要求"按这个风格做一份"
3. 项目需要**架构深研**（架构、治理、自进化等多维度纵深，1500-3000 字）
4. 项目需要**竞品研究**（含 web_search 实时调研）
5. 用户要"分章节叙事"而非"扫读式仪表盘"

**不要用于**：周会汇报、bug 列表、签字归档、决策投票——那些用 biz-html-viz。

## 工作流程

### Step 1 — 强制读 design-system-deck

`references/design-system-deck.md` 定义了所有 3 个模板共享的 CSS 变量、组件库、动画规则、视觉禁令。**未读直接写 = 视觉不一致**。

### Step 2 — 选模板

| 用户意图 | 模板 |
|---|---|
| 阶段汇报、项目状态、Roadmap 走读、对外里程碑展示 | `stage-report.html` |
| 系统架构、治理模型、技术深度纵深、ADR 集 | `architecture-deep.html` |
| 竞品对比、技术雷达、市场格局、相关技术对照 | `competitive-landscape.html` |

需要多份时**分别生成**——不要把架构深研和竞品对比塞在一份里。

### Step 3 — Competitive-Landscape 必须先调研

**强制**先读 `references/research-playbook.md`，然后按 3 档自适应执行：

- 用户给 git URL → Tier 3 (web_fetch README/docs)
- 用户给竞品名 list → Tier 2 (web_search 每家 2-3 次)
- 用户什么都没给 → Tier 1 (web_search 三轮自动发现)

**严禁仅凭训练数据写竞品对比**。每条断言必须有 `data-source` 引用。

### Step 4 — 填充内容

复制 `templates/{name}.html` → 替换所有 `{{占位符}}` → 输出到用户指定目录或 `output/`。

文件名格式：`{YYYY-MM-DD}-{type}-{slug}-deck.html`，例：
- `2026-05-10-stage-octarus-w19d3-deck.html`
- `2026-05-10-arch-mingjing-deck.html`
- `2026-05-10-compete-finance-intel-deck.html`

### Step 5 — 一致性检查

生成完毕后核对：

1. 每章是否都有 `eyebrow + kicker-num + h2 + lead` 四件套
2. `reveal` 类是否覆盖所有应入场的元素
3. `prefers-reduced-motion` 降级是否生效
4. （仅 competitive）所有外部断言是否都有 `data-source`
5. References 章节是否齐全

## 内容质量规则

- **每章 lead 一句话定调**——讲演节奏感来源
- **主视觉一份报告只一个**——orbit / canvas / SVG knowledge graph 选一种
- **章节数控制 5-8 章**——少了没分量，多了观众累
- **每章 250-600 字**——讲演不是论文
- **所有数字用真值**——估值标 `[ESTIMATED]`，缺失标 `[N/A]`，**严禁编造**
- **竞品评价用对方的话**——不要用本项目术语去框对方

## 模板清单

```
templates/
├── stage-report.html              通用阶段报告（Octarus v2 通用化）
├── architecture-deep.html         架构深研（系统/治理/自进化多维度）
└── competitive-landscape.html     竞品对比（含 web 调研）
```

## 反模式

- ❌ 跳过 design-system-deck.md 直接写
- ❌ 三个模板视觉风格漂移
- ❌ Competitive 模板没做 web_search 就写
- ❌ 章节缺 eyebrow / kicker-num / lead 任一
- ❌ 一份报告塞两种主视觉
- ❌ 用 biz-html-viz 的黑黄配色（那是另一个 skill）
- ❌ 未提供 prefers-reduced-motion 降级
- ❌ 留下未替换的 `{{占位符}}`
