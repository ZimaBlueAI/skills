# critique-5dim: 5 维专家评审协议

> v2 新增。完整评分标准、场景侧重、常见问题、输出模板**全部在** `~/.claude/skills/huashu-design/references/critique-guide.md`。本文件做的是**viz-deck 适配**：什么时候触发、对 4 个产出模式分别怎么评、怎么生成可视化雷达。

## 5 维一句话定义

| # | 维度 | 一句话 |
|---|---|---|
| 1 | **哲学一致性** | 是否真的执行了所选的 20 哲学之一，每个细节都有依据 |
| 2 | **视觉层级** | 用户视线是否按设计者意图自然流动 |
| 3 | **细节执行** | 像素级精确——对齐、间距、颜色、字体无瑕疵 |
| 4 | **功能性** | 每个元素都服务于目标，零冗余 |
| 5 | **创新性** | 在哲学框架内找到独特表达，不是模板套用 |

每项 0-10 打分，**总评 = 5 项算术均值**。

- 8+ = 优秀
- 6-7.9 = 良好
- 4-5.9 = 需改进
- < 4 = 不合格（必须返工）

## 何时触发评审

| 场景 | 是否自动触发 |
|---|:---:|
| 用户明确说"评审一下"、"打个分"、"5 维评一下"、"好不好看" | ✅ 必触发 |
| 用户用 "/critique" / "/review" / "review this design" | ✅ 必触发 |
| 一份 deck 第一次产出完成时 | ⚠️ 默认不触发；如果用户在过去 3 轮内有"挑剔"信号（"不够好"、"再改改"），自动触发 |
| biz-decision-stack 走完全流程 orchestrator | ✅ 触发（作为最后一步质量把关） |
| 用户问"还能再优化吗" | ✅ 触发——评审 + Quick Wins 是最直接的答案 |

## 4 个模式各自的侧重

不同产出形态评审重点不同（与 huashu 原表对齐）：

| viz-deck 模式 | 最重要 | 次重要 | 可放宽 |
|---|---|---|---|
| **keynote-report** | 视觉层级、功能性 | 细节执行 | 创新性（清晰优先） |
| **prototype** | 功能性、细节执行 | 视觉层级 | 哲学一致性（可用性优先） |
| **slide-deck** | 视觉层级、功能性 | 细节执行 | 创新性（清晰优先） |
| **motion-stage** | 创新性、视觉层级 | 哲学一致性 | 功能性（叙事优先） |

## 评审输出格式

调用 huashu 的标准模板，包成 viz-deck 的 HTML 评审报告：

```
## 设计评审报告

**模式**：keynote-report / prototype / slide-deck / motion-stage
**目标哲学**：18 Kenya Hara · 东方哲学派
**总体评分**：7.8/10 [良好]

**分项**：
- 哲学一致性：8/10 — 留白节奏到位，但有 1 处用了 Inter 而非衬线
- 视觉层级：8/10 — h1/h2 对比 3.2 倍，符合
- 细节执行：7/10 — 第 3 屏右下角 8px 偏移
- 功能性：8/10 — 信息密度匹配 keynote 节奏
- 创新性：7/10 — 没有惊喜，但稳

### Keep（优点）
- 留白占比 65%，符合 Kenya Hara 的"空"哲学
- 字体单一（Noto Serif JP），层级靠字重而非字体家族

### Fix（问题，按严重度）
**⚡重要**：第 5 屏 Inter font-family 漏改 → 改成 Noto Serif JP
**💡优化**：第 3 屏对齐 → 检查 grid-column 是否漏写
**💡优化**：CTA 颜色 #C8B07E 偏暗 → 提到 #D4BA85 增强可读性

### Quick Wins（5 分钟必修）
- [ ] 第 5 屏字体替换
- [ ] 第 3 屏对齐修复
- [ ] CTA 提亮 1 档
```

## 可视化雷达（嵌入评审报告）

5 维评分用 ECharts radar，调用 viz-charts skill：

```html
<figure class="chart-echarts">
  <div data-echarts-option='{
    "radar": {
      "indicator": [
        {"name":"哲学一致性","max":10},
        {"name":"视觉层级","max":10},
        {"name":"细节执行","max":10},
        {"name":"功能性","max":10},
        {"name":"创新性","max":10}
      ]
    },
    "series": [{
      "type":"radar",
      "data":[{"value":[8,8,7,8,7],"name":"当前评分"}]
    }]
  }' style="width:100%;height:320px"></div>
  <figcaption>图 · 5 维设计评审雷达</figcaption>
</figure>
```

## 关键检查项（自动触发部分）

每次产出完成后，先做"自评"——5 项各自至少检查 1 个客观指标，再决定是否要呈现完整评审给用户：

| 维度 | 客观检查项 | 触发返工的红线 |
|---|---|---|
| 哲学一致性 | grep 出非目标哲学的视觉关键词（emoji / 紫色渐变 / 玻璃拟态） | 出现 1 个 = -2 分 |
| 视觉层级 | 标题与正文字号比 | < 2.5 倍 = ≤ 6 分 |
| 细节执行 | 间距是否都在 8/16/24/32/48/64 px | 出现"奇数"间距 = -1 分 |
| 功能性 | 删一个元素 deck 会变差吗 | 至少 80% 元素必须通过 |
| 创新性 | 是否复用了 deck-stage 的"轨道环"主视觉而无微调 | 完全复用 = ≤ 6 分 |

## v2.1 · Reflective Loop（页面级自检）

> 灵感来自 PPTAgent（4.4k Star）— "Agentic Framework for Reflective PowerPoint Generation"。AI 做的 PPT 之所以丑，是因为它**没有回头看**的环节。

### 何时触发

- 模式 5（pptx-deck）生成完 spec JSON 后**自动跑**一遍
- 用户问"质量怎么样"、"还能再优化吗"
- 走完 motion-stage 或 slide-deck 后准备交付前

### 工作流

```bash
# 1. 生成 deck 后（spec 已写好），跑反思
node ~/.claude/skills/viz-deck/scripts/reflect-and-redo.mjs \
  --spec deck.json \
  --output ./reflect-report.html \
  --threshold 7.0 \
  --redo-prompts ./redo.txt

# 2. 看 reflect-report.html
#    - Deck mean
#    - 各维度均分
#    - 每页打分表（flagged 行红色）
#    - 每个 issue 是具体可修复的（"KPI 'X' 没有单位"）

# 3. 编辑 deck.json 修每个 issue → 重跑 make-pptx-deck.mjs
# 4. 再跑一次 reflect-and-redo.mjs 验证
```

### 客观打分 vs 主观打分

| 维度 | 类型 | reflect-and-redo.mjs 处理 |
|---|---|---|
| D1 哲学一致性 | 主观 | 不打分，默认 7.0 中性 → 必须 LLM 看渲染后判 |
| D2 视觉层级 | 客观 | bullet 数 / KPI 数 / 标题字数 |
| D3 细节执行 | 客观 | placeholder 残留 / 缺单位 / Lorem ipsum |
| D4 功能性 | 客观 | layout 与 fields 匹配（kpi-grid 没 kpis = -5） |
| D5 创新性 | 主观 | 不打分，默认 7.0 中性 → 必须 LLM 看渲染后判 |

### 阈值与处理

- 单页 < 5.0 = **必须重做** → 加入 redo-prompts.txt
- 单页 5.0-7.0 = **建议改进** → 在 report 表里红行
- Deck 均分 < 6.0 = **全 deck 推倒重来**（哲学没对、节奏崩了）

### 反模式

- ❌ 跑 reflect 但**不读 report** → 没意义
- ❌ 用 reflect 给 deck 打"自我表扬"的高分（脚本不会，但人写 LLM prompt 会）
- ❌ Threshold 设到 4.0 让所有页过线 → 自欺欺人
- ❌ 主观维度（D1/D5）默认按 7.0 算就完事——必须人工审

## 与设计方向顾问的闭环

评审报告**末尾**永远提一句：

> 如果你想要不一样的方向，可以让我用另一个哲学（19 Irma Boom / 02 Stamen Design / ...）重做一版，看对比效果。

把评审结果反哺回设计方向顾问——5 维评分低 + 用户不满意 = 触发"换风格"建议。

## 不要做的事

- ❌ 在 viz-deck 文件里复述完整的 huashu 评分标准——引用即可
- ❌ 5 项任意一项给 10 分（人类设计师都做不到，10 分留给真的"惊艳"的产出）
- ❌ 评审只说优点不说问题——用户来要评分不是来要鼓励
- ❌ 给出 > 3 条 Quick Wins——观众做不到那么多，挑最影响力的 3 条
- ❌ 评审里讨论"主观品味"——只评 5 维硬指标
